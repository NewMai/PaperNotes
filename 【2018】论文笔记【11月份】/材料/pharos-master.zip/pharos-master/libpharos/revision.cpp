#include "revision.hpp"

namespace pharos {

const char * REVISION =
  #include "PHAROS_REVISION.ii"
  ;

} // namespace pharos
