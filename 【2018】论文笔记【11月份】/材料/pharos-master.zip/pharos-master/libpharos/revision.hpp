#ifndef Pharos_REVISION_HPP_
#define Pharos_REVISION_HPP_

namespace pharos {
extern const char * REVISION;
};

#endif  // Pharos_REVISION_HPP_
